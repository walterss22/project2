Scott Walters
1738908
On my honor, I have neither given nor received any unacknowledged aid on this assignment.
Scott Walters